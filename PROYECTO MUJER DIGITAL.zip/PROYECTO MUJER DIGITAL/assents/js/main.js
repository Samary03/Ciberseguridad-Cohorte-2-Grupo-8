let display = document.getElementById('display');
let expression = '';

function Numero(num) {
  expression += num;
  display.value = expression;
}

function appendOperator(operator) {
  expression += operator;
  display.value = expression;
}

function calculate() {
  try {
    let result = eval(expression);
    display.value = result;
    expression = '';
  } catch (error) {
    display.value = 'Error';
  }
}

function clearScreen() {
  expression = '';
  display.value = '';
}

